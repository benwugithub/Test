﻿namespace EnCodingConvert
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTrans = new System.Windows.Forms.Button();
            this.txtSource = new System.Windows.Forms.TextBox();
            this.txtBig5 = new System.Windows.Forms.TextBox();
            this.txtUnicode = new System.Windows.Forms.TextBox();
            this.txtUtf8 = new System.Windows.Forms.TextBox();
            this.txtUtf8_INT = new System.Windows.Forms.TextBox();
            this.txtUnicode_INT = new System.Windows.Forms.TextBox();
            this.txtUnicodeLE = new System.Windows.Forms.TextBox();
            this.txtUnicodeLE_INT = new System.Windows.Forms.TextBox();
            this.txtUtf8UrlEncode = new System.Windows.Forms.TextBox();
            this.txtBig5UrlEncode = new System.Windows.Forms.TextBox();
            this.txtNCR = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnUrlDecode_Big5 = new System.Windows.Forms.Button();
            this.btnUrlDecode_UTF8 = new System.Windows.Forms.Button();
            this.txtUrlDecodeBig5 = new System.Windows.Forms.TextBox();
            this.txtUrlDecodeUtf8 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.ddlSourceEncoding = new System.Windows.Forms.ComboBox();
            this.ddlCodePage = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.btnCht2Bytes = new System.Windows.Forms.Button();
            this.btnByte2Char = new System.Windows.Forms.Button();
            this.txtSourceCht = new System.Windows.Forms.TextBox();
            this.txtBytes = new System.Windows.Forms.TextBox();
            this.txtbyte2String = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.NCRtoWord = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnTrans
            // 
            this.btnTrans.Location = new System.Drawing.Point(580, 31);
            this.btnTrans.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTrans.Name = "btnTrans";
            this.btnTrans.Size = new System.Drawing.Size(100, 29);
            this.btnTrans.TabIndex = 0;
            this.btnTrans.Text = "轉換";
            this.btnTrans.UseVisualStyleBackColor = true;
            this.btnTrans.Click += new System.EventHandler(this.btnTrans_Click);
            // 
            // txtSource
            // 
            this.txtSource.Location = new System.Drawing.Point(176, 31);
            this.txtSource.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSource.Name = "txtSource";
            this.txtSource.Size = new System.Drawing.Size(377, 25);
            this.txtSource.TabIndex = 1;
            // 
            // txtBig5
            // 
            this.txtBig5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txtBig5.Location = new System.Drawing.Point(176, 291);
            this.txtBig5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtBig5.Name = "txtBig5";
            this.txtBig5.ReadOnly = true;
            this.txtBig5.Size = new System.Drawing.Size(503, 25);
            this.txtBig5.TabIndex = 2;
            // 
            // txtUnicode
            // 
            this.txtUnicode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txtUnicode.Location = new System.Drawing.Point(176, 151);
            this.txtUnicode.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtUnicode.Name = "txtUnicode";
            this.txtUnicode.ReadOnly = true;
            this.txtUnicode.Size = new System.Drawing.Size(503, 25);
            this.txtUnicode.TabIndex = 3;
            // 
            // txtUtf8
            // 
            this.txtUtf8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txtUtf8.Location = new System.Drawing.Point(176, 81);
            this.txtUtf8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtUtf8.Name = "txtUtf8";
            this.txtUtf8.ReadOnly = true;
            this.txtUtf8.Size = new System.Drawing.Size(503, 25);
            this.txtUtf8.TabIndex = 4;
            // 
            // txtUtf8_INT
            // 
            this.txtUtf8_INT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtUtf8_INT.Location = new System.Drawing.Point(176, 116);
            this.txtUtf8_INT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtUtf8_INT.Name = "txtUtf8_INT";
            this.txtUtf8_INT.ReadOnly = true;
            this.txtUtf8_INT.Size = new System.Drawing.Size(503, 25);
            this.txtUtf8_INT.TabIndex = 5;
            // 
            // txtUnicode_INT
            // 
            this.txtUnicode_INT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtUnicode_INT.Location = new System.Drawing.Point(176, 186);
            this.txtUnicode_INT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtUnicode_INT.Name = "txtUnicode_INT";
            this.txtUnicode_INT.ReadOnly = true;
            this.txtUnicode_INT.Size = new System.Drawing.Size(503, 25);
            this.txtUnicode_INT.TabIndex = 6;
            // 
            // txtUnicodeLE
            // 
            this.txtUnicodeLE.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txtUnicodeLE.Location = new System.Drawing.Point(176, 221);
            this.txtUnicodeLE.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtUnicodeLE.Name = "txtUnicodeLE";
            this.txtUnicodeLE.ReadOnly = true;
            this.txtUnicodeLE.Size = new System.Drawing.Size(503, 25);
            this.txtUnicodeLE.TabIndex = 7;
            // 
            // txtUnicodeLE_INT
            // 
            this.txtUnicodeLE_INT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtUnicodeLE_INT.Location = new System.Drawing.Point(176, 256);
            this.txtUnicodeLE_INT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtUnicodeLE_INT.Name = "txtUnicodeLE_INT";
            this.txtUnicodeLE_INT.ReadOnly = true;
            this.txtUnicodeLE_INT.Size = new System.Drawing.Size(503, 25);
            this.txtUnicodeLE_INT.TabIndex = 8;
            // 
            // txtUtf8UrlEncode
            // 
            this.txtUtf8UrlEncode.Location = new System.Drawing.Point(176, 504);
            this.txtUtf8UrlEncode.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtUtf8UrlEncode.Name = "txtUtf8UrlEncode";
            this.txtUtf8UrlEncode.Size = new System.Drawing.Size(377, 25);
            this.txtUtf8UrlEncode.TabIndex = 9;
            // 
            // txtBig5UrlEncode
            // 
            this.txtBig5UrlEncode.Location = new System.Drawing.Point(176, 434);
            this.txtBig5UrlEncode.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtBig5UrlEncode.Name = "txtBig5UrlEncode";
            this.txtBig5UrlEncode.Size = new System.Drawing.Size(377, 25);
            this.txtBig5UrlEncode.TabIndex = 10;
            // 
            // txtNCR
            // 
            this.txtNCR.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtNCR.Location = new System.Drawing.Point(176, 326);
            this.txtNCR.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNCR.Name = "txtNCR";
            this.txtNCR.ReadOnly = true;
            this.txtNCR.Size = new System.Drawing.Size(503, 25);
            this.txtNCR.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 31);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 15);
            this.label1.TabIndex = 12;
            this.label1.Text = "中文";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 295);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 15);
            this.label5.TabIndex = 16;
            this.label5.Text = "Big5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 326);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 15);
            this.label6.TabIndex = 17;
            this.label6.Text = "NCR";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 438);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(114, 15);
            this.label7.TabIndex = 18;
            this.label7.Text = "URLEncode(Big5)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 508);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(126, 15);
            this.label8.TabIndex = 19;
            this.label8.Text = "URLEncode(UTF-8)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(85, 120);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 15);
            this.label9.TabIndex = 20;
            this.label9.Text = "十進制";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(85, 260);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 15);
            this.label10.TabIndex = 21;
            this.label10.Text = "十進制";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(85, 190);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 15);
            this.label11.TabIndex = 22;
            this.label11.Text = "整數值";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 225);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 15);
            this.label4.TabIndex = 15;
            this.label4.Text = "UniCode LE";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 85);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 15);
            this.label2.TabIndex = 13;
            this.label2.Text = "UTF-8";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 155);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 15);
            this.label3.TabIndex = 14;
            this.label3.Text = "UniCode BE";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(17, 400);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(622, 15);
            this.label12.TabIndex = 23;
            this.label12.Text = "---------------------------------------------------------------------------------" +
    "------------------------------------------";
            // 
            // btnUrlDecode_Big5
            // 
            this.btnUrlDecode_Big5.Location = new System.Drawing.Point(580, 431);
            this.btnUrlDecode_Big5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnUrlDecode_Big5.Name = "btnUrlDecode_Big5";
            this.btnUrlDecode_Big5.Size = new System.Drawing.Size(100, 29);
            this.btnUrlDecode_Big5.TabIndex = 24;
            this.btnUrlDecode_Big5.Text = "轉回中文";
            this.btnUrlDecode_Big5.UseVisualStyleBackColor = true;
            this.btnUrlDecode_Big5.Click += new System.EventHandler(this.btnUrlDecode_Big5_Click);
            // 
            // btnUrlDecode_UTF8
            // 
            this.btnUrlDecode_UTF8.Location = new System.Drawing.Point(580, 504);
            this.btnUrlDecode_UTF8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnUrlDecode_UTF8.Name = "btnUrlDecode_UTF8";
            this.btnUrlDecode_UTF8.Size = new System.Drawing.Size(100, 29);
            this.btnUrlDecode_UTF8.TabIndex = 25;
            this.btnUrlDecode_UTF8.Text = "轉回中文";
            this.btnUrlDecode_UTF8.UseVisualStyleBackColor = true;
            this.btnUrlDecode_UTF8.Click += new System.EventHandler(this.btnUrlDecode_UTF8_Click);
            // 
            // txtUrlDecodeBig5
            // 
            this.txtUrlDecodeBig5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txtUrlDecodeBig5.Location = new System.Drawing.Point(176, 469);
            this.txtUrlDecodeBig5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtUrlDecodeBig5.Name = "txtUrlDecodeBig5";
            this.txtUrlDecodeBig5.ReadOnly = true;
            this.txtUrlDecodeBig5.Size = new System.Drawing.Size(503, 25);
            this.txtUrlDecodeBig5.TabIndex = 26;
            // 
            // txtUrlDecodeUtf8
            // 
            this.txtUrlDecodeUtf8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txtUrlDecodeUtf8.Location = new System.Drawing.Point(175, 540);
            this.txtUrlDecodeUtf8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtUrlDecodeUtf8.Name = "txtUrlDecodeUtf8";
            this.txtUrlDecodeUtf8.ReadOnly = true;
            this.txtUrlDecodeUtf8.Size = new System.Drawing.Size(503, 25);
            this.txtUrlDecodeUtf8.TabIndex = 27;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(15, 582);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(622, 15);
            this.label13.TabIndex = 28;
            this.label13.Text = "---------------------------------------------------------------------------------" +
    "------------------------------------------";
            // 
            // ddlSourceEncoding
            // 
            this.ddlSourceEncoding.FormattingEnabled = true;
            this.ddlSourceEncoding.Items.AddRange(new object[] {
            "utf8",
            "Unicode LE(小尾序,MS預設值)",
            "Unicode BE(大尾序)",
            "Big5",
            "GB2312",
            "ASCII",
            "西歐語系 (ISO)"});
            this.ddlSourceEncoding.Location = new System.Drawing.Point(393, 616);
            this.ddlSourceEncoding.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ddlSourceEncoding.Name = "ddlSourceEncoding";
            this.ddlSourceEncoding.Size = new System.Drawing.Size(160, 23);
            this.ddlSourceEncoding.TabIndex = 29;
            // 
            // ddlCodePage
            // 
            this.ddlCodePage.FormattingEnabled = true;
            this.ddlCodePage.Items.AddRange(new object[] {
            "utf8",
            "Unicode LE(小尾序,MS預設值)",
            "Unicode BE(大尾序)",
            "Big5",
            "GB2312",
            "ASCII",
            "西歐語系 (ISO)"});
            this.ddlCodePage.Location = new System.Drawing.Point(393, 696);
            this.ddlCodePage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ddlCodePage.Name = "ddlCodePage";
            this.ddlCodePage.Size = new System.Drawing.Size(160, 23);
            this.ddlCodePage.TabIndex = 30;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(13, 620);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(37, 15);
            this.label14.TabIndex = 31;
            this.label14.Text = "中文";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(16, 655);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(38, 15);
            this.label15.TabIndex = 32;
            this.label15.Text = "Bytes";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(13, 696);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(37, 15);
            this.label16.TabIndex = 33;
            this.label16.Text = "中文";
            // 
            // btnCht2Bytes
            // 
            this.btnCht2Bytes.Location = new System.Drawing.Point(580, 614);
            this.btnCht2Bytes.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCht2Bytes.Name = "btnCht2Bytes";
            this.btnCht2Bytes.Size = new System.Drawing.Size(100, 29);
            this.btnCht2Bytes.TabIndex = 34;
            this.btnCht2Bytes.Text = "轉成Bytes";
            this.btnCht2Bytes.UseVisualStyleBackColor = true;
            this.btnCht2Bytes.Click += new System.EventHandler(this.btnCht2Bytes_Click);
            // 
            // btnByte2Char
            // 
            this.btnByte2Char.Location = new System.Drawing.Point(577, 696);
            this.btnByte2Char.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnByte2Char.Name = "btnByte2Char";
            this.btnByte2Char.Size = new System.Drawing.Size(100, 29);
            this.btnByte2Char.TabIndex = 35;
            this.btnByte2Char.Text = "轉回中文";
            this.btnByte2Char.UseVisualStyleBackColor = true;
            this.btnByte2Char.Click += new System.EventHandler(this.btnByte2Char_Click);
            // 
            // txtSourceCht
            // 
            this.txtSourceCht.Location = new System.Drawing.Point(79, 616);
            this.txtSourceCht.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSourceCht.Name = "txtSourceCht";
            this.txtSourceCht.Size = new System.Drawing.Size(305, 25);
            this.txtSourceCht.TabIndex = 36;
            // 
            // txtBytes
            // 
            this.txtBytes.Location = new System.Drawing.Point(79, 651);
            this.txtBytes.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtBytes.Name = "txtBytes";
            this.txtBytes.Size = new System.Drawing.Size(475, 25);
            this.txtBytes.TabIndex = 37;
            // 
            // txtbyte2String
            // 
            this.txtbyte2String.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txtbyte2String.Location = new System.Drawing.Point(79, 696);
            this.txtbyte2String.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtbyte2String.Name = "txtbyte2String";
            this.txtbyte2String.ReadOnly = true;
            this.txtbyte2String.Size = new System.Drawing.Size(305, 25);
            this.txtbyte2String.TabIndex = 38;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(17, 366);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(95, 15);
            this.label17.TabIndex = 39;
            this.label17.Text = "NCR轉回中文";
            // 
            // NCRtoWord
            // 
            this.NCRtoWord.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.NCRtoWord.Location = new System.Drawing.Point(176, 362);
            this.NCRtoWord.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.NCRtoWord.Name = "NCRtoWord";
            this.NCRtoWord.ReadOnly = true;
            this.NCRtoWord.Size = new System.Drawing.Size(503, 25);
            this.NCRtoWord.TabIndex = 40;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(703, 739);
            this.Controls.Add(this.NCRtoWord);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.txtbyte2String);
            this.Controls.Add(this.txtBytes);
            this.Controls.Add(this.txtSourceCht);
            this.Controls.Add(this.btnByte2Char);
            this.Controls.Add(this.btnCht2Bytes);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.ddlCodePage);
            this.Controls.Add(this.ddlSourceEncoding);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtUrlDecodeUtf8);
            this.Controls.Add(this.txtUrlDecodeBig5);
            this.Controls.Add(this.btnUrlDecode_UTF8);
            this.Controls.Add(this.btnUrlDecode_Big5);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtNCR);
            this.Controls.Add(this.txtBig5UrlEncode);
            this.Controls.Add(this.txtUtf8UrlEncode);
            this.Controls.Add(this.txtUnicodeLE_INT);
            this.Controls.Add(this.txtUnicodeLE);
            this.Controls.Add(this.txtUnicode_INT);
            this.Controls.Add(this.txtUtf8_INT);
            this.Controls.Add(this.txtUtf8);
            this.Controls.Add(this.txtUnicode);
            this.Controls.Add(this.txtBig5);
            this.Controls.Add(this.txtSource);
            this.Controls.Add(this.btnTrans);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTrans;
        private System.Windows.Forms.TextBox txtSource;
        private System.Windows.Forms.TextBox txtBig5;
        private System.Windows.Forms.TextBox txtUnicode;
        private System.Windows.Forms.TextBox txtUtf8;
        private System.Windows.Forms.TextBox txtUtf8_INT;
        private System.Windows.Forms.TextBox txtUnicode_INT;
        private System.Windows.Forms.TextBox txtUnicodeLE;
        private System.Windows.Forms.TextBox txtUnicodeLE_INT;
        private System.Windows.Forms.TextBox txtUtf8UrlEncode;
        private System.Windows.Forms.TextBox txtBig5UrlEncode;
        private System.Windows.Forms.TextBox txtNCR;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnUrlDecode_Big5;
        private System.Windows.Forms.Button btnUrlDecode_UTF8;
        private System.Windows.Forms.TextBox txtUrlDecodeBig5;
        private System.Windows.Forms.TextBox txtUrlDecodeUtf8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox ddlSourceEncoding;
        private System.Windows.Forms.ComboBox ddlCodePage;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnCht2Bytes;
        private System.Windows.Forms.Button btnByte2Char;
        private System.Windows.Forms.TextBox txtSourceCht;
        private System.Windows.Forms.TextBox txtBytes;
        private System.Windows.Forms.TextBox txtbyte2String;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox NCRtoWord;
    }
}

