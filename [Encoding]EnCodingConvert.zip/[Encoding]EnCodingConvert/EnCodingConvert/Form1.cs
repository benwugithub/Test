﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Web;
using System.Globalization;
//using Microsoft.VisualBasic.PowerPacks;

namespace EnCodingConvert
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
            this.encodingList.Add("utf8", Encoding.UTF8);
            this.encodingList.Add("Unicode LE(小尾序,MS預設值)", Encoding.Unicode);
            this.encodingList.Add("Unicode BE(大尾序)", Encoding.GetEncoding("utf-16BE"));
            this.encodingList.Add("Big5", Encoding.GetEncoding(950));
            this.encodingList.Add("GB2312", Encoding.GetEncoding(0x3a8));
            this.encodingList.Add("ASCII", Encoding.ASCII);
            this.encodingList.Add("西歐語系 (ISO)", Encoding.GetEncoding(28591));
        }

        private Dictionary<string, Encoding> encodingList = new Dictionary<string, Encoding>();

        private void btnTrans_Click(object sender, EventArgs e)
        {
            
            //列舉所有編碼
            //foreach (var e1 in Encoding.GetEncodings())
            //{
            //    this.txtSource.Text += e1.CodePage +" "+ e1.Name+" | ";
            //}

            string source = this.txtSource.Text;
            char chA = 'A';
            if (string.IsNullOrEmpty(source))
            {
                MessageBox.Show("請輸入文字");
                this.txtBig5.Text = this.txtUtf8.Text = this.txtUnicode.Text = "";
            }
            else
            {
                Encoding ec = Encoding.GetEncoding(950);
                this.parse(this.txtBig5, ec, source);


                ec = Encoding.UTF8;
                //Encoding.GetEncoding(65001); 
                this.parse(this.txtUtf8, ec, source);
                this.parseINT(this.txtUtf8_INT, ec, source);
                

                ec = Encoding.GetEncoding("utf-16BE");
                //Encoding.GetEncoding(1201);
                this.parse(this.txtUnicode, ec, source);
                this.parseUnicode2INT(this.txtUnicode_INT, ec, source);
                

                ec = Encoding.Unicode;
                //Encoding.GetEncoding(1200);
                this.parse(this.txtUnicodeLE, ec, source);
                this.parseINT(this.txtUnicodeLE_INT, ec, source);
                this.transNCR(source);

                //NCRtoWord兩種方式結果相同
                this.NCRtoWord.Text= this.fromNCR(this.txtNCR.Text);
                //this.NCRtoWord.Text = HttpUtility.HtmlDecode(source);

                this.txtBig5UrlEncode.Text = HttpUtility.UrlEncode(source, Encoding.GetEncoding(950));
                this.txtUtf8UrlEncode.Text = HttpUtility.UrlEncode(source, Encoding.UTF8);

            }
        }


        private void parse(TextBox target, Encoding ec, string source)
        {
            StringBuilder sb = new StringBuilder();
            //foreach (char c in source)
            //{
            //    byte[] bytes = ec.GetBytes(new char[] { c });
            //    foreach (byte b in bytes)
            //    {
            //        sb.AppendFormat("{0:X2} ", b);
            //    }
            //    sb.Append(", ");
            //}
            //由於 Unicode 的總字數超過 65536 個字元，有些罕見字的編碼會超過 2 bytes，例如此例的「𩗴」（讀作四聲「ㄅㄥˋ」），
            //這個字的編碼佔 4 bytes，若使用 str[0] 的方式取出第一個字元，就會只抓到整個 Unicode 字元的一半，因而出現亂碼
            Int32[] textElemIndex = StringInfo.ParseCombiningCharacters(source);
            for (Int32 i = 0; i < textElemIndex.Length; i++)
            {
                byte[] bytes = ec.GetBytes(StringInfo.GetNextTextElement(source, textElemIndex[i]));
                foreach (byte b in bytes)
                {
                    sb.AppendFormat("{0:X2} ", b);
                }
                sb.Append(", ");
            }
            string result = sb.ToString();
            if (result.Length > 2)
            {
                result = result.Substring(0, result.Length - 2);
            }
            target.Text = result;
        }

        private void parseINT(TextBox target, Encoding ec, string source)
        {
            StringBuilder sb = new StringBuilder();
            //foreach (char c in source)
            //{
            //    byte[] bytes = ec.GetBytes(new char[] { c });
            //    foreach (byte b in bytes)
            //    {
            //        sb.AppendFormat("{0:D3} ", b);
            //    }
            //    sb.Append(", ");
            //}
            Int32[] textElemIndex = StringInfo.ParseCombiningCharacters(source);
            for (Int32 i = 0; i < textElemIndex.Length; i++)
            {
                byte[] bytes = ec.GetBytes(StringInfo.GetNextTextElement(source, textElemIndex[i]));
                foreach (byte b in bytes)
                {
                    sb.AppendFormat("{0:D3} ", b);
                }
                sb.Append(", ");
            }
            string result = sb.ToString();
            if (result.Length > 2)
            {
                result = result.Substring(0, result.Length - 2);
            }
            target.Text = result;
        }

        private void parseUnicode2INT(TextBox target, Encoding ec, string source)
        {
            StringBuilder sb = new StringBuilder();
            //foreach (char c in source)
            //{
            //    sb.AppendFormat("{0} , ", Convert.ToInt32(c));
            //}
            Int32[] textElemIndex = StringInfo.ParseCombiningCharacters(source);
            for (Int32 i = 0; i < textElemIndex.Length; i++)
            {
                byte[] bytes = ec.GetBytes(StringInfo.GetNextTextElement(source, textElemIndex[i]));
                foreach (byte b in bytes)
                {
                    sb.AppendFormat("{0:D3} ", b);
                }
                sb.Append(", ");
            }
            string result = sb.ToString();
            if (result.Length > 2)
            {
                result = result.Substring(0, result.Length - 2);
            }
            target.Text = result;
        }

        private void transNCR(string source)
        {
            //Encoding ec = Encoding.GetEncoding(950);
            //StringBuilder sb = new StringBuilder();
            //foreach (char c in source)
            //{
            //    byte[] bytes = ec.GetBytes(new char[] { c });
            //    if (bytes.Length == 2)
            //    {
            //        sb.Append(c);
            //    }
            //    else if (ec.GetString(bytes) != "?")
            //    {
            //        sb.Append(c);
            //    }
            //    else if (c == '?')
            //    {
            //        sb.Append(c);
            //    }
            //    else
            //    {
            //        sb.AppendFormat("&#{0};", Convert.ToInt32(c));
            //    }
            //}
            //NCR  (  Numeric character reference )
            //utf-8 4bytes字轉NCR會是錯的，還找不到正確處理方式。ex:𨑨
            //Char.ConvertToUtf32("𨑨", 0);
            StringBuilder sb = new StringBuilder();
            string str = source;
            //for (int i = 0; i < str.Length; i++)
            //{
            //    char c = str[i];
            //    if (c <= '\u007F')
            //    {
            //        sb.Append(c);
            //    }
            //    else
            //    {
            //        sb.AppendFormat("&#{0};", Convert.ToInt32(c));
            //    }
            //}
            Int32[] textElemIndex = StringInfo.ParseCombiningCharacters(source);
            for (Int32 i = 0; i < textElemIndex.Length; i++)
            {
                string SingleWord = StringInfo.GetNextTextElement(source, textElemIndex[i]);
                sb.AppendFormat("&#{0};", Char.ConvertToUtf32(SingleWord, 0));
            }
            this.txtNCR.Text = sb.ToString();
        }

        private void btnUrlDecode_Big5_Click(object sender, EventArgs e)
        {
            this.txtUrlDecodeBig5.Text = HttpUtility.UrlDecode(this.txtBig5UrlEncode.Text, Encoding.GetEncoding(950));
        }

        private void btnUrlDecode_UTF8_Click(object sender, EventArgs e)
        {
            this.txtUrlDecodeUtf8.Text = HttpUtility.UrlDecode(this.txtUtf8UrlEncode.Text, Encoding.UTF8);
        }

        private void btnCht2Bytes_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(System.IO.Path.Combine("C:\\TEMP\\", "F1.TXT"));
            //MessageBox.Show(System.IO.Path.GetTempFileName());

            string ecKey = (string)this.ddlSourceEncoding.SelectedItem;
            if (string.IsNullOrEmpty(this.txtSourceCht.Text.Trim()))
            {
                MessageBox.Show("請輸入 中文");
                this.txtBytes.Text = this.txtbyte2String.Text = "";
            }
            else if (string.IsNullOrEmpty(ecKey))
            {
                MessageBox.Show("請選編碼方式");
                this.txtBytes.Text = this.txtbyte2String.Text = "";
            }
            else
            {
                string txtSource = this.txtSourceCht.Text;
                byte[] bytes = this.encodingList[ecKey].GetBytes(txtSource);
                StringBuilder sb = new StringBuilder();
                foreach (byte b in bytes)
                {
                    sb.AppendFormat("{0:X2}", b);
                }
                this.txtBytes.Text = sb.ToString();
                this.btnByte2Char_Click(null, EventArgs.Empty);
            }
        }

        private void btnByte2Char_Click(object sender, EventArgs e)
        {
            string ecKey = (string)this.ddlCodePage.SelectedItem;
            if (string.IsNullOrEmpty(this.txtBytes.Text.Trim()))
            {
                MessageBox.Show("請輸入 bytes");
                this.txtbyte2String.Text = "";
            }
            else if (string.IsNullOrEmpty(ecKey))
            {
                MessageBox.Show("請選編碼方式");
                this.txtbyte2String.Text = "";
            }
            else
            {
                try
                {
                    byte[] bytes = this.Hex2Bytes(this.txtBytes.Text.Trim());
                    this.txtbyte2String.Text = this.encodingList[ecKey].GetString(bytes);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private byte[] Hex2Bytes(string value)
        {
            value = value.Replace(" ", "");
            if ((value.Length % 2) == 1)
            {
                throw new ArgumentException("bytes字數必需為偶數");
            }
            byte[] rtn = new byte[value.Length / 2];
            for (int i = 0; i < value.Length; i += 2)
            {
                string code = value.Substring(i, 2);
                rtn[i / 2] = Convert.ToByte(code, 0x10);
            }
            return rtn;
        }

        private string fromNCR(string s) 
        {
            //http://blog.darkthread.net/post-2007-12-11-convert-from-ncr.aspx
            foreach (System.Text.RegularExpressions.Match m in System.Text.RegularExpressions.Regex.Matches(s, "&#(?<ncr>\\d+?);"))
            {   
                string value = m.Value;
                //char chr = Convert.ToChar(int.Parse(m.Groups["ncr"].Value));
                string chr = char.ConvertFromUtf32(int.Parse(m.Groups["ncr"].Value));
                s = s.Replace(value, chr.ToString());
            }
            return s;
        }

    }
}
